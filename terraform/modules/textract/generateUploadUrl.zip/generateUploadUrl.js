const { S3Client, PutObjectCommand } = require("@aws-sdk/client-s3");
const { getSignedUrl } = require("@aws-sdk/s3-request-presigner");

const REGION = "us-east-1";
const s3Client = new S3Client({ region: REGION });

exports.handler = async (event) => {
  const imageName = event.queryStringParameters?.name;
  const bucketName = process.env.BUCKET_NAME;

  if (!imageName || !bucketName) {
    return {
      statusCode: 400,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: "Missing image name or bucket." }),
    };
  }

  const command = new PutObjectCommand({
    Bucket: bucketName,
    Key: imageName,
    ContentType: "image/jpeg",
  });

  const uploadUrl = await getSignedUrl(s3Client, command, { expiresIn: 300 });

  return {
    statusCode: 200,
    headers: { "Access-Control-Allow-Origin": "*" },
    body: JSON.stringify({ upload_url: uploadUrl }),
  };
};
