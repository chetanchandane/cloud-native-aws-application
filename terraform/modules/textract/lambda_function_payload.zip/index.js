const { TextractClient, AnalyzeDocumentCommand } = require("@aws-sdk/client-textract");
const { DynamoDBClient, PutItemCommand } = require("@aws-sdk/client-dynamodb");

const textract = new TextractClient({ region: "us-east-1" });
const dynamo = new DynamoDBClient({ region: "us-east-1" });

exports.handler = async (event) => {
  const bucket = process.env.BUCKET_NAME;
  const table = process.env.TABLE_NAME;
  const key = event.queryStringParameters?.name;

  if (!key) {
    return {
      statusCode: 400,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: "Missing image key" }),
    };
  }

  try {
    const textractResponse = await textract.send(
      new AnalyzeDocumentCommand({
        Document: { S3Object: { Bucket: bucket, Name: key } },
        FeatureTypes: ["FORMS"],
      })
    );

    const blocks = textractResponse.Blocks || [];

    const extracted = {
      calories: "",
      protein: "",
      carbohydrates: "",
      fat: "",
      imageKey: key,
    };

    for (let i = 0; i < blocks.length; i++) {
      const block = blocks[i];
      if (block.BlockType === "LINE" && block.Text) {
        const text = block.Text.toLowerCase();

        // Calories: either inline or in next line
        if (text.includes("calories") && !text.includes("from fat")) {
          const match = text.match(/calories\s*:?[\s]*([0-9]+)/);
          if (match) {
            extracted.calories = match[1];
          } else if (i + 1 < blocks.length) {
            const nextText = blocks[i + 1].Text?.toLowerCase();
            const nextMatch = nextText?.match(/^([0-9]+)/);
            if (nextMatch) {
              extracted.calories = nextMatch[1];
            }
          }
        }

        // Protein
        if (text.includes("protein")) {
          const match = text.match(/protein.*?([0-9]+(\.[0-9]+)?)/);
          if (match) extracted.protein = match[1];
        }

        // Carbohydrates
        if (text.includes("carbohydrate")) {
          const match = text.match(/carbohydrate.*?([0-9]+(\.[0-9]+)?)/);
          if (match) extracted.carbohydrates = match[1];
        }

        // Total Fat (but ignore Saturated Fat lines)
        if (text.includes("total fat") || (text.includes("fat") && !text.includes("saturated"))) {
          const match = text.match(/fat.*?([0-9]+(\.[0-9]+)?)/);
          if (match) extracted.fat = match[1];
        }
      }
    }

    await dynamo.send(
      new PutItemCommand({
        TableName: table,
        Item: {
          imageKey: { S: extracted.imageKey },
          protein: { S: extracted.protein },
          fat: { S: extracted.fat },
          carbohydrates: { S: extracted.carbohydrates },
          calories: { S: extracted.calories },
        },
      })
    );

    return {
      statusCode: 200,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify(extracted),
    };
  } catch (error) {
    console.error("Textract error:", error);
    return {
      statusCode: 500,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: "Textract processing failed" }),
    };
  }
};
